<?php
/*
 * @Author: Jeay 
 * @Date: 2017-06-23 16:06:27 
 * @Last Modified time: 2017-06-23 16:06:27 
 */
$config = [
    //网站标题
    "webTitle" => "",
    //网站栏目名
    "cateTitle" => [],
    //首页关键词
    "indexKeyword" => "",
    //首页描述
    "indexDescription" => "",
    //模板名
    "tempName" => "",
    //列表页每页显示数量
    "postsNum" => "",
    //是否在url中显示标题
    "urlTitle" => "",
    //是否在标题后面添加随机关键词
    "keywordFileSwitch" => "",
    //sitemap密码，随机生成
    "sitemapPassword" => "",
];